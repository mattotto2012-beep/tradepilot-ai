TradePilot AI — clickable prototype

Open index.html in a browser.

This prototype is UI/demo only. It does not connect to brokers or place real trades.
For a production version, broker authentication must use official APIs/OAuth or other supported secure integrations; never collect or store broker passwords.
