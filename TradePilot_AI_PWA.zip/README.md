# TradePilot AI — PWA Demo

This project is now configured as a Progressive Web App.

## Run
1. Install Node.js 18+.
2. In this folder run `npm start`.
3. Open `http://localhost:3000`.
4. On iPhone Safari, use **Share → Add to Home Screen**.
5. On supported desktop browsers, use the browser's **Install** option.

The app needs to be served over HTTPS when deployed publicly (localhost is allowed for development).

This is a demo/simulation trading app. It does not place real-money trades.
