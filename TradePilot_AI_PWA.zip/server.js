const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = process.env.PORT || 3000;
const publicDir = path.join(__dirname, "public");

let state = {
  balance: 10000,
  equity: 10000,
  dailyPnL: 0,
  positions: [],
  trades: [],
  followed: ["Alex K."]
};

function send(res, code, data, type="application/json") {
  res.writeHead(code, {"Content-Type": type});
  res.end(type.includes("json") ? JSON.stringify(data) : data);
}
function body(req) {
  return new Promise((resolve,reject)=>{
    let b=""; req.on("data",c=>b+=c); req.on("end",()=>{try{resolve(b?JSON.parse(b):{})}catch(e){reject(e)}})
  });
}
function market() {
  return [
    {symbol:"EURUSD", price:1.1724, change:0.42},
    {symbol:"XAUUSD", price:3742.80, change:0.71},
    {symbol:"BTCUSD", price:112480, change:-0.18},
    {symbol:"NAS100", price:24580, change:0.31}
  ];
}
function serveFile(req,res) {
  let u = new URL(req.url, "http://localhost");
  let file = u.pathname === "/" ? "index.html" : u.pathname.slice(1);
  let p = path.normalize(path.join(publicDir,file));
  if (!p.startsWith(publicDir) || !fs.existsSync(p)) return send(res,404,"Not found","text/plain");
  let ext=path.extname(p), types={".html":"text/html",".js":"text/javascript",".css":"text/css",".json":"application/json"};
  send(res,200,fs.readFileSync(p),types[ext]||"text/plain");
}
const server=http.createServer(async(req,res)=>{
  try {
    if(req.method==="GET" && req.url==="/api/state") return send(res,200,{...state,market:market()});
    if(req.method==="POST" && req.url==="/api/reset"){state={balance:10000,equity:10000,dailyPnL:0,positions:[],trades:[],followed:["Alex K."]};return send(res,200,state)}
    if(req.method==="POST" && req.url==="/api/scan"){
      const m=market();
      const setups=[
        {symbol:"EURUSD",side:"BUY",entry:m[0].price,sl:m[0].price-0.004,tp:m[0].price+0.008,confidence:87},
        {symbol:"XAUUSD",side:"BUY",entry:m[1].price,sl:m[1].price-18,tp:m[1].price+36,confidence:78}
      ];
      return send(res,200,{setups});
    }
    if(req.method==="POST" && req.url==="/api/demo-order"){
      const x=await body(req); const risk=Math.max(1,Math.min(100,Number(x.risk||1)));
      const p=market().find(a=>a.symbol===x.symbol); if(!p) return send(res,400,{error:"Unknown symbol"});
      const trade={id:Date.now(),symbol:x.symbol,side:x.side||"BUY",entry:p.price,risk,openedAt:new Date().toISOString()};
      state.positions.push(trade); state.trades.unshift(trade); return send(res,200,{trade,state});
    }
    if(req.method==="POST" && req.url==="/api/follow"){
      const x=await body(req); if(!state.followed.includes(x.name)) state.followed.push(x.name);
      return send(res,200,{followed:state.followed});
    }
    if(req.method==="GET") return serveFile(req,res);
    send(res,404,{error:"Not found"});
  } catch(e){ send(res,500,{error:e.message}); }
});
server.listen(PORT,()=>console.log(`TradePilot running on http://localhost:${PORT}`));
