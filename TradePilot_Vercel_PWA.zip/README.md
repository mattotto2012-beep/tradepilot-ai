# TradePilot AI — Vercel-ready PWA

This is a self-contained demo PWA. It works without a backend and stores demo account state in the browser.

## Deploy to Vercel
Upload this folder/repository to Vercel with the **Root Directory** set to the project root. No build command is required.

The `public` folder is served as the static site.

## Important
This is demo/simulation software. It does not connect to brokers or place real-money trades. Real MT5, TradingView, and TradeLocker execution requires official APIs/OAuth, secure server-side credentials, user authentication, persistent storage, and additional risk/compliance controls.
